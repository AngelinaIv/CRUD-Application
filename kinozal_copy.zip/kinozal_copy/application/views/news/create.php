<form action="/news/create" method="post">
	
	<input type="input" name="slug" placeholder="slug"></br>
	<input type="input" name="title" placeholder="news name"></br>
	<textarea name="text" placeholder="news text"></textarea></br>
	<input type="submit"name="submit"value="добавить новость">
</form>